# Lib

This folder is for importable python libraries/packages.


---
Start of auto-generated file data.<br/>Last updated: 2021-05-08 12:10:16

<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>File</th>
      <th>Summary</th>
      <th>Line Count</th>
      <th>Last Modified</th>
      <th>Size</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>__init__.py</td>
      <td>_</td>
      <td>1</td>
      <td>2021-04-09 20:25:38</td>
      <td>21.00 b</td>
    </tr>
    <tr>
      <td>config.py</td>
      <td>_</td>
      <td>17</td>
      <td>2021-04-15 20:56:51</td>
      <td>415.00 b</td>
    </tr>
    <tr>
      <td>core.py</td>
      <td>Core functionality that ties together multiple APIs.</td>
      <td>266</td>
      <td>2021-05-07 18:38:25</td>
      <td>10.82 kb</td>
    </tr>
    <tr>
      <td>openai_utils.py</td>
      <td>Utility functions for interacting with the gpt3 api.</td>
      <td>130</td>
      <td>2021-05-07 18:38:25</td>
      <td>4.96 kb</td>
    </tr>
    <tr>
      <td>utils.py</td>
      <td>General purpose utilities.</td>
      <td>273</td>
      <td>2021-05-07 18:38:25</td>
      <td>9.92 kb</td>
    </tr>
    <tr>
      <td>youtube.py</td>
      <td>Functionality to fetch and work with YouTube transcripts.</td>
      <td>106</td>
      <td>2021-05-07 18:38:25</td>
      <td>3.50 kb</td>
    </tr>
  </tbody>
</table>
<br/>End of auto-generated file data. Do not add anything below this.
